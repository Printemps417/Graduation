import './App.css';
import MapComponent from './MapContainer';

function App() {
  return (
    <div className="App">
      <MapComponent></MapComponent>
    </div>
  );
}

export default App;
